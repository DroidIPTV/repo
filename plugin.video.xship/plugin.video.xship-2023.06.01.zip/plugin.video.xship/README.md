
## Willkommen bei Xship für Kodi!

Bei Xship handelt es sich um ein Video-Addon für Kodi, welches das Streamen von Filmen und Serien über eine intuitive und optisch ansprechende Benutzeroberfläche ermöglicht

Der Schwerpunkt des Addons liegt darin, die Indexseiten lauffähig zu halten

Die Angebotenen Webseiten werden als Indexseiten bezeichnet, welche auf die eigentlichen Quellen verweisen die für das bereitgestellte Angebot verantworlich sind! 

