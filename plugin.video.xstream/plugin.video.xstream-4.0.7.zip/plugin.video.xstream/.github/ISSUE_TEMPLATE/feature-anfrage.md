---
name: Feature Anfrage
about: Schlag uns eine Idee für das Projekt vor
title: Feature Anfrage
labels: Feature Request
assignees: ''

---

**Bezieht sich die Feature-Anfrage auf ein Problem? Bitte beschreiben**
Eine klare Beschreibung was das Problem ist. "Entschuldigung, Ich bin immer frustriert wenn [...]" oder "Es gibt immer Probleme wenn ich (das mache)..........

**Beschreibe eine Lösung die du gerne haben möchteste**
Eine klare Beschreibung was du haben möchtest

**Beschreibe eine Alternative die du in Betracht ziehst**
Eine klare Beschreibung von jeder alternativen Lösung oder vom Feature das du dir überlegt hast

**Zusätzliche Informationen**
Füge hier zusätzliche Informationen ein oder ein Screenshot zu deiner Feature Anfrage
