import sys
import os
import json
import urllib.request, urllib.parse, urllib.error
import urllib.parse
import xbmcaddon
import xbmcgui
import xbmcplugin
import load_channels
import hashlib
import re
import time
import xbmcvfs
import config
import shutil
from zipfile import ZipFile


addon       = xbmcaddon.Addon('plugin.video.stalker')
addonname   = addon.getAddonInfo('name')
addondir    = xbmcvfs.translatePath( addon.getAddonInfo('profile') ) 
dialog = xbmcgui.Dialog()
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])
go = True
icon0 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon1 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon2 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon3 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon4 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon5 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon6 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon7 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon8 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon9 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon10 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon11 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon12 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon13 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon14 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon15 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon16 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon17 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon18 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon19 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon20 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon21 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon22 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon23 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon24 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')
icon25 = xbmcvfs.translatePath('special://home/addons/plugin.video.stalker/resources/icons/icon.png')

xbmcplugin.setContent(addon_handle, 'movies')




def addPortal(portal):

    if portal['url'] == '':
        return;

    url = build_url({
        'mode': 'sel', 
        'portal' : json.dumps(portal)
        });   
    
    li = xbmcgui.ListItem(portal['name'])
    li.setArt({'icon':icon0})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
    #xbmcgui.Dialog().notification(addonname, '[COLOR red]MegaMod[/COLOR] by [COLOR orange]ANON[/COLOR]',sound=False)
    
def build_url(query):
    return base_url + '?' + urllib.parse.urlencode(query)


def homeLevel():

    global portal_1, portal_2, portal_3, portal_4, portal_5, portal_6, portal_7, portal_8, portal_9, portal_10, portal_11, portal_12, portal_13, portal_14, portal_15, portal_16, portal_17, portal_18, portal_19, portal_20, portal_21, portal_22, portal_23, portal_24, portal_25, portal_26, portal_27, portal_28, portal_29, portal_30, portal_30, portal_31, portal_32, portal_33, portal_34, portal_35, portal_36, portal_37, portal_38, portal_39, portal_40, portal_41, portal_42, portal_43, portal_44, portal_45, portal_46, portal_47, portal_48, portal_49, portal_50, portal_51, portal_52, portal_53, portal_54, portal_55, portal_56, portal_57, portal_58, portal_59, portal_60, portal_61, portal_62, portal_63, portal_64, portal_65, portal_66, portal_67, portal_68, portal_69, portal_70, portal_71, portal_72, portal_73, portal_74, portal_75, portal_76, portal_77, portal_78, portal_79, portal_80, portal_81, go;
    
    #todo - check none portal

    if go:
        addPortal(portal_1);
        addPortal(portal_2);
        addPortal(portal_3);
        addPortal(portal_4);
        addPortal(portal_5);
        addPortal(portal_6);
        addPortal(portal_7);
        addPortal(portal_8);
        addPortal(portal_9);
        addPortal(portal_10);
        addPortal(portal_11);
        addPortal(portal_12);
        addPortal(portal_13);
        addPortal(portal_14);
        addPortal(portal_15);
        addPortal(portal_16);
        addPortal(portal_17);  
        addPortal(portal_18);
        addPortal(portal_19);
        addPortal(portal_20);
        addPortal(portal_21);
        addPortal(portal_22);
        addPortal(portal_23);
        addPortal(portal_24);
        addPortal(portal_25);
        addPortal(portal_26);
        addPortal(portal_27);
        addPortal(portal_28);
        addPortal(portal_29);
        addPortal(portal_30);
        addPortal(portal_31);
        addPortal(portal_32);
        addPortal(portal_33);
        addPortal(portal_34);
        addPortal(portal_35);
        addPortal(portal_36);
        addPortal(portal_37);
        addPortal(portal_38);
        addPortal(portal_39);
        addPortal(portal_40);
        addPortal(portal_41);
        addPortal(portal_42);
        addPortal(portal_43);
        addPortal(portal_44);
        addPortal(portal_45);
        addPortal(portal_46);
        addPortal(portal_47);
        addPortal(portal_48);
        addPortal(portal_49);
        addPortal(portal_50);
        addPortal(portal_51);
        addPortal(portal_52);
        addPortal(portal_53);
        addPortal(portal_54);
        addPortal(portal_55);
        addPortal(portal_56);
        addPortal(portal_57);  
        addPortal(portal_58);
        addPortal(portal_59);
        addPortal(portal_60);
        addPortal(portal_61);
        addPortal(portal_62);
        addPortal(portal_63);
        addPortal(portal_64);
        addPortal(portal_65);
        addPortal(portal_66);
        addPortal(portal_67);
        addPortal(portal_68);
        addPortal(portal_69);
        addPortal(portal_70);
        addPortal(portal_71);
        addPortal(portal_72);
        addPortal(portal_73);
        addPortal(portal_74);
        addPortal(portal_75);
        addPortal(portal_76);
        addPortal(portal_77);
        addPortal(portal_78);
        addPortal(portal_79);
        addPortal(portal_80);
        addPortal(portal_81);
        xbmcplugin.endOfDirectory(addon_handle);

def SelectLevel():

    url = build_url({
        'mode': 'genres', 
        'portal' : json.dumps(portal)
        });
       
    
    li = xbmcgui.ListItem('[B]LiVE.TV[/B]')
    li.setArt({'icon':icon1})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    url = build_url({
        'mode': 'vodgen', 
        'portal' : json.dumps(portal)
        });
       
    
    li = xbmcgui.ListItem('[B]VoD[/B]')
    li.setArt({'icon':icon2})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({
        'mode': 'sergen', 
        'portal' : json.dumps(portal)
        });
       
    
    li = xbmcgui.ListItem('[B]SERiEN[/B]')
    li.setArt({'icon':icon3})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)    
    
    


    url = build_url({
        'mode': 'cache', 
        'portal' : json.dumps(portal)
        });
       
    
    li = xbmcgui.ListItem('CACHE LEEREN')
    li.setArt({'icon':icon4})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle);

    
    xbmcplugin.endOfDirectory(addon_handle);
    
    
 
def ClearLevel():
   filelist = [ f for f in os.listdir(addondir) if not f.endswith(".xml") ]
   for f in filelist:
       os.remove(os.path.join(addondir, f))
       
def genreLevel():
    
    try:
        data = load_channels.getGenres(portal['mac'], portal['url'], portal['serial'], addondir);
        
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
        
        return;

    data = data['genres'];
    
    for id, i in list(data.items()):

        title     = i["title"];
        
        url = build_url({
            'mode': 'channels', 
            'genre_id': id, 
            'genre_name': title.title(), 
            'portal' : json.dumps(portal)
            });
            
        if id == '10':
            iconImage = 'OverlayLocked.png';
        else:
            iconImage = 'DefaultVideo.png';
            
          
        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon':icon1}) 
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
        

    xbmcplugin.endOfDirectory(addon_handle);

def channelLevel():
    stop=False; 
        
    try:
        data = load_channels.getAllChannels(portal['mac'], portal['url'], portal['serial'], addondir);
        
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
        return;
    
    
    data = data['channels'];
    genre_name     = args.get('genre_name', None);
    
    genre_id_main = args.get('genre_id', None);
    genre_id_main = genre_id_main[0];
    
    if genre_id_main == '10' and portal['parental'] == 'true':
        result = xbmcgui.Dialog().input('Parental', hashlib.md5(portal['password'].encode('utf-8')).hexdigest(), type=xbmcgui.INPUT_PASSWORD, option=xbmcgui.PASSWORD_VERIFY);
        if result == '':
            stop = True;

    
    if stop == False:
        for i in data:
            
            name         = i["name"];
            cmd         = i["cmd"];
            tmp         = i["tmp"];
            number         = i["number"];
            genre_id     = i["genre_id"];
            logo         = i["logo"];
        
            if genre_id_main == '*' and genre_id == '10' and portal['parental'] == 'true':
                continue;
        
        
            if genre_id_main == genre_id or genre_id_main == '*':
        
                if logo != '':
                    logo_url = portal['url'] + '/stalker_portal/misc/logos/320/' + logo;
                else:
                    logo_url = 'DefaultVideo.png';
                
                
                url = build_url({
                    'mode': 'check', 
                    'cmd': cmd, 
                    'tmp' : tmp, 
                    'title' : name,
                    'genre_name' : genre_name,
                    'logo_url' : logo_url,  
                    'portal' : json.dumps(portal)
                    });
            

                li = xbmcgui.ListItem(name);
                li.setArt({'icon':logo})
                li.setInfo(type='Video', infoLabels={ 
                    'title': name,
                    'count' : number,
                    'plot' : "'NIX im Moment'"
                    });

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li);
        
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PLAYLIST_ORDER);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_PROGRAM_COUNT);
        
        
        xbmcplugin.endOfDirectory(addon_handle);

def vodgenreLevel():
    
    try:
        data = load_channels.getVoDgenres(portal['mac'], portal['url'], portal['serial'], addondir);
        
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
        
        return;

    data = data['vodgenres'];
    
    for id, i in list(data.items()):

        title     = i["title"];
        cat     = i["cat"];
        
        url = build_url({
            'mode': 'vod', 
            'genre_name': title.title(),
            'cat' : cat,        
            'portal' : json.dumps(portal)
            });
            
        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon':icon2})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
        

    xbmcplugin.endOfDirectory(addon_handle);

def vodLevel():
    
    try:
        data = load_channels.getVoD(portal['mac'], portal['url'], portal['serial'], addondir);
        
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
        return;
    cat     = args['cat'][0];    
    
    data = data['vod'+cat];
    
        
    for i in data:
        name     = i["name"];
        cmd     = i["cmd"];
        logo     = i["logo"];
        plot     = i["plot"];
        year     = i["year"];
        genre     = i["genre"];
        #cast     = i['cast'];
        #imdb     = i['imdb']
        
        #actors = [{"name": cast }]
        if logo != '':
            logo_url = portal['url'] + logo;
        else:
            logo_url = 'DefaultVideo.png';
                
                
        url = build_url({
                'mode': 'playvod', 
                'cmd': cmd, 
                'tmp' : '0', 
                'title' : name,
                'genre_name' : 'VoD',
                'logo_url' : logo_url, 
                'portal' : json.dumps(portal)
                });
            

        li = xbmcgui.ListItem(name )
        li.setInfo(type='Video', infoLabels={ 
                                            'title': name, 
                                            'plot' : plot, 
                                            'year' : year, 
                                            'genre' : genre,
                                            #'rating' : imdb
                                            #'cast' : list([cast])
                                            })
        #li.setCast(actors)
        #li.getRating('imdb', imdb )
        li.setArt({'icon':logo})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)
    
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE);
    xbmcplugin.endOfDirectory(addon_handle);

def SeriesGenre():
    
    try:
        data = load_channels.getSergenres(portal['mac'], portal['url'], portal['serial'], addondir);
        
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
        
        return;

    data = data['sergenres'];
    
    for id, i in list(data.items()):

        title     = i["title"];
        cat     = i["cat"];
        
        url = build_url({
            'mode': 'seriescat', 
            'genre_name': title.title(),
            'cat' : cat,        
            'portal' : json.dumps(portal)
            });
            
        li = xbmcgui.ListItem(title.title())
        li.setArt({'icon':icon3})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True);
        

    xbmcplugin.endOfDirectory(addon_handle);


def SeriesLevel():
    
    try:
        data = load_channels.getSeries(portal['mac'], portal['url'], portal['serial'], addondir);
        
    except Exception as e:
        
        return;
    cat     = args['cat'][0];    
    
    data = data['ser'+cat];
    
        
    for i in data:
        name     = i["name"];
        cmd     = i["cmd"];
        logo     = i["logo"];
        plot     = i["plot"];
        year     = i["year"];
        genre     = i["genre"];
        cat     = i['cat']
        category     = i['category']
        
        if logo != '':
            logo_url = portal['url'] + logo;
        else:
            logo_url = 'DefaultVideo.png';
                
                
        url = build_url({
                'mode': 'season', 
                'cat' : cat,                
                'name' : name,
                'cmd' : cmd,
                'category' : category,
                'logo_url' : logo_url, 
                'portal' : json.dumps(portal)
                });
            

        li = xbmcgui.ListItem(name )
        li.setInfo(type='Video', infoLabels={ 
                                            'name': name,                                            
                                            'plot' : plot, 
                                            'year' : year, 
                                            'genre' : genre,
                                            #'rating' : imdb
                                            #'cast' : list([cast])
                                            })
        #li.setCast(actors)
        #li.getRating('imdb', imdb )
        li.setArt({'icon':logo})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE);
    xbmcplugin.endOfDirectory(addon_handle);


def SeasonLevel():
    
    try:
        data = load_channels.get_seasons(portal['mac'], portal['url'], portal['serial'], addondir);
        
    except Exception as e:
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
        return;
    cat     = args['cat'][0];    
    
    data = data['seasons'+ cat];
  
    for i in data:
        name     = i["name"];
        cmd     = i["cmd"];
        logo     = i["logo"];
        cat     = i["cat"];
        category     = i["category"];
        year     = i['year']
        plot     = i['plot']
        genre     = i['genre']

        
        if logo != '':
            logo_url = portal['url'] + logo;
        else:
            logo_url = 'DefaultVideo.png';
                
                
        url = build_url({
                'mode': 'episode',
                'cat' : cat,
                'category' : category,
                'name' : name,
                'cmd' : cmd,
                'portal' : json.dumps(portal)
                });
            

        li = xbmcgui.ListItem(name)
        li.setInfo(type='Video', infoLabels={ 
                                            'name': name,                                            
                                            'plot' : plot, 
                                            'genre' : genre,
                                            })
        
        li.setArt({'icon':logo})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE);
    xbmcplugin.endOfDirectory(addon_handle);

def EpisodeLevel():
    cat     = args['cat'][0];    
    data = load_channels.get_episodes(portal['mac'], portal['url'], portal['serial'], addondir);

    data = data['episodes'];
  
    for i in data:
        name     = i["name"];
        cmd     = i["cmd"];
        cat     = i["cat"];
        category     = i["category"];
        series     = i["series"];
        episode     = i["episode"];

        url = build_url({
                'mode': 'epiplay',
                'episode' : episode,
                'name' : name,
                'cat' : cat,
                'category' : category,
                'cmd' : cmd,
                'portal' : json.dumps(portal)
                });
            
        cat1 = args.get('cat', None);
        cat1 = cat1[0];
        if cat1 == cat:
        
            li = xbmcgui.ListItem(str(episode))
            li.setInfo(type='Video', infoLabels={ 
                                            'name': episode,                                            
                                            })

            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_UNSORTED);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_TITLE);
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_GENRE);
    xbmcplugin.endOfDirectory(addon_handle);

      
def checkcmd():
    
    cmd     = args['cmd'][0]
    if str(cmd).startswith('ffmpeg http://localhost') is True:
        load_channels.getTvStream(portal['mac'], portal['url'], portal['serial'], addondir);
    else:
        playLevel();



def playLevel():
    
    dp = xbmcgui.DialogProgressBG();
    dp.create('IPTV', 'Loading ...');
    
    title     = args['title'][0];
    cmd     = args['cmd'][0];
    tmp     = args['tmp'][0];
    genre_name     = args['genre_name'][0];
    logo_url     = args['logo_url'][0];
    
    try:
        if genre_name != 'VoD':
            url = load_channels.retriveUrl(portal['mac'], portal['url'], portal['serial'], cmd, tmp);
        else:
            url = load_channels.retrive_defaultUrl(portal['mac'], portal['url'], portal['serial'], cmd);

    
    except Exception as e:
        dp.close();
        xbmcgui.Dialog().notification(addonname, str(e), xbmcgui.NOTIFICATION_ERROR );
        return;

    
    dp.update(80);
    
    title = title;
    
    title += ' (' + portal['name'] + ')';
    
#    li = xbmcgui.ListItem(title, iconImage=logo_url); <modified 9.0.19
    li = xbmcgui.ListItem(title);
    li.setInfo('video', {'Title': title, 'Genre': genre_name});
    xbmc.Player().play(item=url, listitem=li);
    
    dp.update(100);
    
    dp.close();

def playStreamLevel():
    
    load_channels.getStream(portal['mac'], portal['url'], portal['serial'], addondir);
 
def PlayEpisode(): 

    load_channels.getEpistream(portal['mac'], portal['url'], portal['serial'], addondir)

mode = args.get('mode', None);
portal =  args.get('portal', None)


if portal is None:
    portal_81 = config.portalConfig('81');
    portal_80 = config.portalConfig('80');
    portal_79 = config.portalConfig('79');
    portal_78 = config.portalConfig('78');
    portal_77 = config.portalConfig('77');
    portal_76 = config.portalConfig('76');
    portal_75 = config.portalConfig('75');
    portal_74 = config.portalConfig('74');
    portal_73 = config.portalConfig('73');
    portal_72 = config.portalConfig('72');
    portal_71 = config.portalConfig('71');
    portal_70 = config.portalConfig('70');
    portal_69 = config.portalConfig('69');
    portal_68 = config.portalConfig('68');
    portal_67 = config.portalConfig('67');
    portal_66 = config.portalConfig('66');
    portal_65 = config.portalConfig('65');
    portal_64 = config.portalConfig('64');
    portal_63 = config.portalConfig('63');
    portal_62 = config.portalConfig('62');
    portal_61 = config.portalConfig('61');
    portal_60 = config.portalConfig('60');
    portal_59 = config.portalConfig('59');
    portal_58 = config.portalConfig('58');
    portal_57 = config.portalConfig('57');
    portal_56 = config.portalConfig('56');
    portal_55 = config.portalConfig('55');
    portal_54 = config.portalConfig('54');
    portal_53 = config.portalConfig('53');
    portal_52 = config.portalConfig('52');
    portal_51 = config.portalConfig('51');
    portal_50 = config.portalConfig('50');
    portal_49 = config.portalConfig('49');
    portal_48 = config.portalConfig('48');
    portal_47 = config.portalConfig('47');
    portal_46 = config.portalConfig('46');
    portal_45 = config.portalConfig('45');
    portal_44 = config.portalConfig('44');
    portal_43 = config.portalConfig('43');
    portal_42 = config.portalConfig('42');
    portal_41 = config.portalConfig('41');
    portal_40 = config.portalConfig('40');
    portal_39 = config.portalConfig('39');
    portal_38 = config.portalConfig('38');
    portal_37 = config.portalConfig('37');
    portal_36 = config.portalConfig('36');
    portal_35 = config.portalConfig('35');
    portal_34 = config.portalConfig('34');
    portal_33 = config.portalConfig('33');
    portal_32 = config.portalConfig('32');
    portal_31 = config.portalConfig('31');
    portal_30 = config.portalConfig('30');
    portal_29 = config.portalConfig('29');
    portal_28 = config.portalConfig('28');
    portal_27 = config.portalConfig('27');
    portal_26 = config.portalConfig('26');
    portal_25 = config.portalConfig('25');
    portal_24 = config.portalConfig('24');
    portal_23 = config.portalConfig('23');
    portal_22 = config.portalConfig('22');
    portal_21 = config.portalConfig('21');
    portal_20 = config.portalConfig('20');
    portal_19 = config.portalConfig('19');
    portal_18 = config.portalConfig('18');
    portal_17 = config.portalConfig('17');
    portal_16 = config.portalConfig('16');
    portal_15 = config.portalConfig('15');
    portal_14 = config.portalConfig('14');
    portal_13 = config.portalConfig('13');
    portal_12 = config.portalConfig('12');
    portal_11 = config.portalConfig('11');
    portal_10 = config.portalConfig('10');
    portal_9 = config.portalConfig('9');
    portal_8 = config.portalConfig('8');
    portal_7 = config.portalConfig('7');
    portal_6 = config.portalConfig('6');
    portal_1 = config.portalConfig('1');
    portal_2 = config.portalConfig('2');
    portal_3 = config.portalConfig('3');
    portal_4 = config.portalConfig('4');
    portal_5 = config.portalConfig('5');
    
    
    

else:
    portal = json.loads(portal[0]);

#  Modification to force outside call to portal_1 (9.0.19)

    portal_2 = config.portalConfig('2');
    portal_3 = config.portalConfig('3');
    portal_4 = config.portalConfig('4');
    portal_5 = config.portalConfig('5');
    portal_6 = config.portalConfig('6');
    portal_7 = config.portalConfig('7');
    portal_8 = config.portalConfig('8');
    portal_9 = config.portalConfig('9');
    portal_10 = config.portalConfig('10');
    portal_11 = config.portalConfig('11');
    portal_12 = config.portalConfig('12');
    portal_13 = config.portalConfig('13');
    portal_14 = config.portalConfig('14');
    portal_15 = config.portalConfig('15');
    portal_16 = config.portalConfig('16');
    portal_17 = config.portalConfig('17');
    portal_18 = config.portalConfig('18');
    portal_19 = config.portalConfig('19');
    portal_20 = config.portalConfig('20');
    portal_21 = config.portalConfig('21');
    portal_22 = config.portalConfig('22');
    portal_23 = config.portalConfig('23');
    portal_24 = config.portalConfig('24');
    portal_25 = config.portalConfig('25');
    portal_26 = config.portalConfig('26');
    portal_27 = config.portalConfig('27');
    portal_28 = config.portalConfig('28');
    portal_29 = config.portalConfig('29');
    portal_30 = config.portalConfig('30');
    portal_31 = config.portalConfig('31');
    portal_32 = config.portalConfig('32');
    portal_33 = config.portalConfig('33');
    portal_34 = config.portalConfig('34');
    portal_35 = config.portalConfig('35');
    portal_36 = config.portalConfig('36');
    portal_37 = config.portalConfig('37');
    portal_38 = config.portalConfig('38');
    portal_39 = config.portalConfig('39');
    portal_40 = config.portalConfig('40');
    portal_41 = config.portalConfig('41');
    portal_42 = config.portalConfig('42');
    portal_43 = config.portalConfig('43');
    portal_44 = config.portalConfig('44');
    portal_45 = config.portalConfig('45');
    portal_46 = config.portalConfig('46');
    portal_47 = config.portalConfig('47');
    portal_48 = config.portalConfig('48');
    portal_49 = config.portalConfig('49');
    portal_50 = config.portalConfig('50');
    portal_51 = config.portalConfig('51');
    portal_52 = config.portalConfig('52');
    portal_53 = config.portalConfig('53');
    portal_54 = config.portalConfig('54');
    portal_55 = config.portalConfig('55');
    portal_56 = config.portalConfig('56');
    portal_57 = config.portalConfig('57');
    portal_58 = config.portalConfig('58');
    portal_59 = config.portalConfig('59');
    portal_60 = config.portalConfig('60');
    portal_61 = config.portalConfig('61');
    portal_62 = config.portalConfig('62');
    portal_63 = config.portalConfig('63');
    portal_64 = config.portalConfig('64');
    portal_65 = config.portalConfig('65');
    portal_66 = config.portalConfig('66');
    portal_67 = config.portalConfig('67');
    portal_68 = config.portalConfig('68');
    portal_69 = config.portalConfig('69');
    portal_70 = config.portalConfig('70');
    portal_71 = config.portalConfig('71');
    portal_72 = config.portalConfig('72');
    portal_73 = config.portalConfig('73');
    portal_74 = config.portalConfig('74');
    portal_75 = config.portalConfig('75');
    portal_76 = config.portalConfig('76');
    portal_77 = config.portalConfig('77');
    portal_78 = config.portalConfig('78');
    portal_79 = config.portalConfig('79');
    portal_80 = config.portalConfig('80');
    portal_81 = config.portalConfig('81');
    if not ( portal['name'] == portal_2['name'] or portal['name'] == portal_3['name'] or portal['name'] == portal_4['name'] or portal['name'] == portal_5['name'] or portal['name'] == portal_6['name'] or portal['name'] == portal_7['name'] or portal['name'] == portal_8['name'] or portal['name'] == portal_9['name'] or portal['name'] == portal_10['name'] or portal['name'] == portal_11['name'] or portal['name'] == portal_12['name'] or portal['name'] == portal_13['name'] or portal['name'] == portal_14['name'] or portal['name'] == portal_15['name'] or portal['name'] == portal_16['name'] or portal['name'] == portal_17['name'] or portal['name'] == portal_18['name'] or portal['name'] == portal_19['name'] or portal['name'] == portal_20['name'] or portal['name'] == portal_21['name'] or portal['name'] == portal_22['name'] or portal['name'] == portal_23['name'] or portal['name'] == portal_24['name'] or portal['name'] == portal_25['name'] or portal['name'] == portal_26['name'] or portal['name'] == portal_27['name'] or portal['name'] == portal_28['name'] or portal['name'] == portal_29['name'] or portal['name'] == portal_30['name'] or portal['name'] == portal_31['name'] or portal['name'] == portal_32['name'] or portal['name'] == portal_33['name'] or portal['name'] == portal_34['name'] or portal['name'] == portal_35['name'] or portal['name'] == portal_36['name'] or portal['name'] == portal_37['name'] or portal['name'] == portal_38['name'] or portal['name'] == portal_39['name'] or portal['name'] == portal_40['name'] or portal['name'] == portal_41['name'] or portal['name'] == portal_42['name'] or portal['name'] == portal_43['name'] or portal['name'] == portal_44['name'] or portal['name'] == portal_45['name'] or portal['name'] == portal_46['name'] or portal['name'] == portal_47['name'] or portal['name'] == portal_48['name'] or portal['name'] == portal_49['name'] or portal['name'] == portal_50['name'] or portal['name'] == portal_51['name'] or portal['name'] == portal_52['name'] or portal['name'] == portal_53['name'] or portal['name'] == portal_54['name'] or portal['name'] == portal_55['name'] or portal['name'] == portal_56['name'] or portal['name'] == portal_57['name'] or portal['name'] == portal_58['name'] or portal['name'] == portal_59['name'] or portal['name'] == portal_60['name'] or portal['name'] == portal_61['name'] or portal['name'] == portal_62['name'] or portal['name'] == portal_63['name'] or portal['name'] == portal_64['name'] or portal['name'] == portal_65['name'] or portal['name'] == portal_66['name'] or portal['name'] == portal_67['name'] or portal['name'] == portal_68['name'] or portal['name'] == portal_69['name'] or portal['name'] == portal_70['name'] or portal['name'] == portal_71['name'] or portal['name'] == portal_72['name'] or portal['name'] == portal_73['name'] or portal['name'] == portal_74['name'] or portal['name'] == portal_75['name'] or portal['name'] == portal_76['name'] or portal['name'] == portal_77['name'] or portal['name'] == portal_78['name'] or portal['name'] == portal_79['name'] or portal['name'] == portal_80['name'] or portal['name'] == portal_81['name'] ) :
        portal = config.portalConfig('1');

    

if mode is None:
    homeLevel();
    
elif mode[0] == 'cacheoptions':    
    CacheLevel();    
    
elif mode[0] == 'downcache':    
    getCache();
    
elif mode[0] == 'cache':    
    ClearLevel();

elif mode[0] == 'sel':
    SelectLevel();

elif mode[0] == 'genres':
    genreLevel();

elif mode[0] == 'vodgen':
    vodgenreLevel();
        
elif mode[0] == 'vod':
    vodLevel();

elif mode[0] == 'channels':
    channelLevel();
    
elif mode[0] == 'play':
    playLevel();

elif mode[0] == 'playvod':
    playStreamLevel();

elif mode[0] == 'check':
    checkcmd();

elif mode[0] == 'sergen':
    SeriesGenre();

elif mode[0] == 'seriescat':
    SeriesLevel();
    
elif mode[0] == 'season':
    SeasonLevel();

elif mode[0] == 'episode':
    EpisodeLevel();

elif mode[0] == 'epiplay':
    PlayEpisode();