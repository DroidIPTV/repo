import json as jsonmod
import xbmcvfs
import xbmcgui
import xbmcplugin
import re
import urllib
import urllib.request
from urllib import parse
import urllib.request as ur
import time
import xbmc
import os
import sys
import xbmcaddon
import requests
import base64
from resources.lib import utils
from resources.lib import sign

DEBUG = os.path.exists(xbmcvfs.translatePath('special://home/debug'))
addonID = 'plugin.video.vavoo.to'
parameter = {}
parameter['output'] = 'json'

params = str.encode(jsonmod.dumps(parameter))
req = urllib.request.Request('https://www2.vavoo.to/live2/index?output=json', headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36'})
req.add_header('Content-Type', 'application/json; charset=utf-8')
response = ur.urlopen(req)
content = response.read().decode('utf8')
result = jsonmod.loads(content)

groups = {}
flagPath = 'special://xbmc/addons/plugin.video.vavoo.to/flags/country/'
#xbmcgui.Dialog().textviewer('TEST_VIEWER',str(result))
for c in result:
    if c['group'] not in groups:
        groups[c['group']] = {}
    g = groups[c['group']]
    name = re.sub('( (SD|HD|FHD|UHD|H265))?( \\(BACKUP\\))? \\(\\d+\\)$', '', c['name'])
    if name not in g:
        g[name] = []
    g[name].append(c)

class Player(xbmc.Player):
    pass

def convertPluginParams(params):
    p = []
    for key, value in params.items():
        if isinstance(value, str):
            value = value.encode('utf-8')
        p.append(parse.urlencode({key: value}))

    return '&'.join(sorted(p))

def getPluginUrl(params):
    return 'plugin://' + addonID + '/?' + convertPluginParams(params)

def livePlay(action, groups, group, name):
    try:
        m = groups[group][name]
        m[0]
    except IndexError:
        xbmcgui.Dialog().ok('Der Kanal ist aktuell nicht erreichbar.', 'Bitte versuche es erneut.')
        return
        
    if len(m) > 1 or DEBUG:
        captions = list(sorted([n['name'] for n in m ]))
        index = xbmcgui.Dialog().select('Stream wählen', captions)
        if index < 0:
            raise ValueError('Abgebrochen')
        n = m[index]
    else:
        n = m[0]
    progress = xbmcgui.DialogProgress()
    try:
        progress.create('VAVOO', u'Stream wird gestartet...')
        progress.update(3)
        o = xbmcgui.ListItem()
        o.setInfo('Video', {'title': n['name'], 'Seekable': 'false', 'SeekEnabled': 'false'})
        o.setLabel(n['name'])
        o.setPath(n['url'] + '?n=1&b=5&vavoo_auth=' + sign.getAuthSignature() + '|User-Agent=VAVOO/2.6')
        o.setProperty('IsPlayable', 'true')
        o.setProperty('IsNotSeekable', 'true')
        o.setProperty('Seekable', 'false')
        o.setProperty('SeekEnabled', 'false')
        progress.update(15)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, o)
        progress.update(20)
        abortReason = ''
        step = 1
        t = time.time()
        player = Player()
        try:
            while not abortReason:
                if progress.iscanceled():
                    abortReason = 'cancelled'
                elif time.time() - t > 15:
                    abortReason = 'timeout'
                elif step == 1:
                    if player.isPlaying():
                        progress.update(30)
                        step = 2
                if step == 2:
                    if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                        progress.update(45)
                        step = 3
                if step == 3:
                    if player.getTime() > 0.01:
                        progress.update(100)
                        xbmcgui.Dialog().notification('', 'Viel Spass mit VAVOO', xbmcgui.NOTIFICATION_INFO, 1500, False)
                        break
                if not abortReason:
                    xbmc.sleep(15)
            if abortReason:
                player.stop()
                xbmcgui.Dialog().ok('Der Kanal ist derzeit nicht erreichbar.', 'Bitte versuche es erneut.')
        finally:
            del player
    finally:
        if progress:
            progress.close()
            del progress

def liveGroupIndex(action, groups, group):
    gName = group.encode('utf-8')
    g = groups[group]
    for name, m in sorted(g.items()):
        name = name.strip().encode('utf-8')
        url = getPluginUrl({'action': action, 'group': gName, 'name': name})
        for n in m:
            if n['logo']:
                o = xbmcgui.ListItem(name)
                o.setArt({"icon": 'special://home/addons/plugin.video.vavoo.to/flags/channel.png', "thumb": n['logo']})
                break
        else:
            o = xbmcgui.ListItem(name)
            o.setArt({"icon": 'special://home/addons/plugin.video.vavoo.to/flags/channel.png'})

        o.setInfo(type='Video', infoLabels={'Title': name})
        o.setProperty('IsPlayable', 'true')
        o.setProperty('selectaction', 'play')
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = url, listitem = o, isFolder = False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)

def liveIndex(action, groups):
    LIVE_GROUP_ALIASES = ((u'Germany', u'Deutschland', 'de.png', None),
         (u'Germany/Sky', u'SKY Deutschland', 'de.png', None),
         (u'DE2', u'Deutschland#2', 'de.png', None),
         (u'Turkey', u'T\xfcrkei', 'tr.png', None),
         (u'Netherlands', u'Niederlande', 'nl.png', None),
         (u'Italy', u'Italien', 'it.png', None),
         (u'France', u'Frankreich', 'fr.png', None),
         (u'United Kingdom', u'England', 'en.png', None),
         (u'Spain', u'Spanien', 'es.png', None),
         (u'Balkans', u'Balkan', 'yu.png', None),
         (u'Switzerland', u'Schweiz', 'ch.png', None),
         (u'Austria', u'Austria', 'at.png', None),
         (u'Portugal', u'Portugal', 'pt.png', None),
         (u'Poland', u'Polen', 'pl.png', None),
         (u'Ukraine', u'Ukraine', 'ua.png', None),
         (u'Belgium', u'Belgien', 'be.png', None),
         (u'Finland', u'Finland', 'fi.png', None),
         (u'Sweden', u'Schweden', 'se.png', None),
         (u'Denmark', u'D\xe4nemark', 'dk.png', None),
         (u'Norway', u'Norwegen', 'no.png', None),
         (u'Scandinavia', u'Skandinavien', 'scd.jpg', None),
         (u'Czech Republic', u'Tschechien', 'cz.png', None),
         (u'Serbia', u'Serbien', 'rs.png', None),
         (u'Slovenia', u'Slovenien', 'si.png', None),
         (u'Bulgaria', u'Bulgarien', 'bg.png', None),
         (u'Romania', u'Rum\xe4nien', 'ro.png', None),
         (u'Greece', u'Griechenland', 'gr.png', None),
         (u'Macedonia', u'Makedonien', 'mk.png', None),
         (u'Estonia', u'Estland', 'ee.png', None),
         (u'Hungary', u'Ungarn', 'hu.png', None),
         (u'Lithuania', u'Litauen', 'lt.png', None),
         (u'Lithunia', u'Litauen', 'li.png', None),
         (u'Malta', u'Malta', 'mt.png', None),
         (u'Albania', u'Albanien', 'al.png', None),
         (u'Russia', u'Russland', 'ru.png', None),
         (u'Israel', u'Israel', 'il.png', None),
         (u'USA', u'USA', 'us.png', None),
         (u'Canada', u'Kanada', 'ca.png', None),
         (u'Brazil', u'Brasilien', 'br.png', None),
         (u'Columbia', u'Kolumbien', 'co.png', None),
         (u'Latin', u'Lateinamerika', 'latin.jpg', None),
         (u'Armenia', u'Armenien', 'am.png', None),
         (u'Armenian', u'Armenien#2', 'am.png', None),
         (u'Arabia', u'Arabisch', 'ae.png', None),
         (u'Azerbaijan', u'Azerbaijan', 'az.png', None),
         (u'Iran', u'Iran', 'ir.png', None),
         (u'Afganisthan', u'Afghanistan', 'af.png', None),
         (u'Afghanistan', u'Afghanistan#2', 'af.png', None),
         (u'Kurdish', u'Kurdistan', 'kur.png', None),
         (u'India', u'Indien', 'in.png', None),
         (u'Pakistan', u'Pakistan', 'pk.png', None),
         (u'Africa', u'Afrika', 'afr.png', None),
         (u'Afrika', u'Afrika#2', 'afr.png', None),
         (u'Seychelles', u'Seychellen', 'sc.png', None),
         (u'Suriname', u'Suriname', 'sr.png', None),
         (u'China', u'China', 'cn.png', None),
         (u'Korea', u'Korea', 'kr.png', None),
         (u'Japan', u'Japan', 'jp.png', None),
         (u'Thailand', u'Thailand', 'th.png', None),
         (u'Malaysia', u'Malaysia', 'my.png', None),
         (u'Nauru', u'Nauru', 'nr.png', None),
         (u'Philippines', u'Philippinen', 'ph.png', None),
         (u'Singapore', u'Singapur', 'sg.png', None),
         (u'Viet Nam', u'Vietnam', 'vn.png', None),
         (u'SKAI DIGITAL', u'SKAI DIGITAL', 'skai.png', None),
         (u'SPORTS', u'SPORTS', 'wsp.jpg', None),
         (u'SPORTS 2', u'SPORTS 2', 'wsp.jpg', None),
         (u'Indonesia', u'Indonesia', 'Indonesia.png', None),
         (u'XXX', u'XXX', 'skai.png', None))
    index = []
    for group, g in groups.items():
        for i, (alias, name, icon, url) in enumerate(LIVE_GROUP_ALIASES):
            if alias == group:
                title = name
                break
        else:
            i, title, icon, url = (99999, group, 'special://home/addons/plugin.video.vavoo.to/flags/channel.png', None)
        if url is None:
            url = getPluginUrl({'action': action, 'group': group.encode('utf-8')})
        index.append((i, title.strip() + u' (' + str(len(g)) + u' Kanäle)', xbmcvfs.translatePath(flagPath + icon), url))
    for i, title, icon, url in sorted(index):
        o = xbmcgui.ListItem(title)
        o.setArt({"icon": icon, "thumb": icon})
        o.setInfo(type = 'Video', infoLabels = {'Title': title})
        o.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = url, listitem = o, isFolder = True)
    xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded = True, cacheToDisc = False)
    return

def list_categories(params):
    action = params.get('action', '')
    if params.get('group') and params.get('name'):
        livePlay(action, groups, params['group'], params['name'])
    elif params.get('group'):
        liveGroupIndex(action, groups, params.get('group'))
    else:
        liveIndex(action, groups)

def begin(paramstring):    
    params = dict(parse.parse_qsl(paramstring))
    list_categories(params)

def stube():
    begin(sys.argv[2][1:])
