﻿# -*- coding: utf-8 -*-

from .common import *


if not xbmcvfs.exists(dataPath):
	xbmcvfs.mkdirs(dataPath)

def mainMenu(): # Auflistung der Kategorien zur Überprüfung: https://search.dfb.de/categories.json?
	addDir(translation(30601), icon, {'mode': 'listBroadcasts'})
	addDir(translation(30602), icon, {'mode': 'listSports_Men'})
	addDir(translation(30603), icon, {'mode': 'listSports_Women'})
	addDir(translation(30604), icon, {'mode': 'listBroadcasts', 'category': 'Amateurfußball'})
	addDir(translation(30605), icon, {'mode': 'listBroadcasts', 'category': 'Futsal'})
	addDir(translation(30606), icon, {'mode': 'listBroadcasts', 'category': 'Fan Club'})
	addDir(translation(30607), icon, {'mode': 'listBroadcasts', 'category': 'English Videos'})
	addDir(translation(30608), icon, {'mode': 'listBroadcasts', 'category': 'DFB-Akademie'})
	addDir(translation(30609), icon, {'mode': 'listBroadcasts', 'category': 'Sportliche Strukturen'})
	addDir(translation(30610), icon, {'mode': 'listBroadcasts', 'category': 'Talentförderung'})
	addDir(translation(30611), artpic+'basesearch.png', {'mode': 'SearchDFBTV'})
	addDir(translation(30612), artpic+'livestream.png', {'mode': 'listLivestreams'})
	if enableADJUSTMENT:
		addDir(translation(30613), artpic+'settings.png', {'mode': 'aConfigs'}, folder=False)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive'):
			addDir(translation(30614), artpic+'settings.png', {'mode': 'iConfigs'}, folder=False)
	if not ADDON_operate('inputstream.adaptive'):
		addon.setSetting('useInputstream', 'false')
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSports_Men():
	debug_MS("(navigator.listSports_Men) -------------------------------------------------- START = listSports_Men --------------------------------------------------")
	addDir(translation(30621), icon, {'mode': 'listBroadcasts', 'category': 'Männer'})
	addDir(translation(30622), icon, {'mode': 'listBroadcasts', 'category': 'Die Mannschaft'})
	addDir(translation(30623), icon, {'mode': 'listBroadcasts', 'category': 'Bundesliga'})
	addDir(translation(30624), icon, {'mode': 'listBroadcasts', 'category': '3. Liga'})
	addDir(translation(30625), icon, {'mode': 'listBroadcasts', 'category': 'A-Junioren-Bundesliga'})
	addDir(translation(30626), icon, {'mode': 'listBroadcasts', 'category': 'B-Junioren-Bundesliga'})
	addDir(translation(30627), icon, {'mode': 'listBroadcasts', 'category': 'DFB-Pokal'})
	addDir(translation(30628), icon, {'mode': 'listBroadcasts', 'category': 'U 21-Männer'})
	addDir(translation(30629), icon, {'mode': 'listBroadcasts', 'category': 'U20-Männer'})
	addDir(translation(30630), icon, {'mode': 'listBroadcasts', 'searching': 'junioren'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listSports_Women():
	debug_MS("(navigator.listSports_Women) -------------------------------------------------- START = listSports_Women --------------------------------------------------")
	addDir(translation(30631), icon, {'mode': 'listBroadcasts', 'category': 'Frauen'})
	addDir(translation(30632), icon, {'mode': 'listBroadcasts', 'category': 'Frauen Nationalmannschaft'})
	addDir(translation(30633), icon, {'mode': 'listBroadcasts', 'category': 'Allianz Frauen-Bundesliga'})
	addDir(translation(30634), icon, {'mode': 'listBroadcasts', 'category': 'FLYERALARM Frauen-Bundesliga'})
	addDir(translation(30635), icon, {'mode': 'listBroadcasts', 'category': 'DFB-Pokal der Frauen'})
	addDir(translation(30636), icon, {'mode': 'listBroadcasts', 'searching': 'juniorinnen'})
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def listBroadcasts(QUERY, CAT, PAGE, LIMIT):
	debug_MS("(navigator.listBroadcasts) -------------------------------------------------- START = listBroadcasts --------------------------------------------------")
	SWAPPED = f'q={QUERY}' if QUERY != 'None' else f'categories={quote(CAT)}'
	NEW_URL = f'https://search.dfb.de/search/videos.json?{SWAPPED}&page={PAGE}'
	content = getUrl(NEW_URL)
	debug_MS(f"(navigator.listBroadcasts) ### NEW_URL : {NEW_URL} ###")
	DATA = json.loads(content)
	if len(DATA['results']) > 0:
		for item in DATA['results']:
			debug_MS(f"(navigator.listBroadcasts[1]) ### ENTRY : {str(item)} ###")
			title = cleaning(item['title'])
			episID = str(item.get('guid', '00')).replace('video-', '')
			plot = cleaning(item.get('description', ''))
			thumb = unquote(item.get('image_url', icon))
			photo = thumb[thumb.find('url=')+4:] if thumb != icon else thumb
			if str(item.get('pub_date'))[7:10].isdigit():
				title = f"{item.get('pub_date')} - {title}"
			debug_MS(f"(navigator.listBroadcasts[2]) ##### TITLE : {title} || episID : {episID} || FOTO : {photo} #####")
			if episID != '00':
				addLink(title, photo, {'mode': 'playVideo', 'url': episID}, plot)
		if DATA.get('total', '') and isinstance(DATA['total'], int) and int(DATA['total']) > int(LIMIT)*int(PAGE):
			debug_MS(f"(navigator.listBroadcasts[3]) PAGES ### Now show NextPage ... No.{str(int(PAGE)+1)} ... ###")
			addDir(translation(30640).format(int(PAGE)+1), artpic+'nextpage.png', {'mode': 'listBroadcasts', 'searching': QUERY, 'category': CAT, 'page': int(PAGE)+1})
	else:
		return dialog.notification(translation(30524).format('Einträge'), translation(30526), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE)

def SearchDFBTV():
	debug_MS("(navigator.SearchDFBTV) ------------------------------------------------ START = SearchDFBTV -----------------------------------------------")
	keyword = None
	if xbmcvfs.exists(searchHackFile):
		with open(searchHackFile, 'r') as look:
			keyword = look.read()
	if xbmc.getInfoLabel('Container.FolderPath') == HOST_AND_PATH: # !!! this hack is necessary to prevent KODI from opening the input mask all the time !!!
		keyword = dialog.input(heading=translation(30641), type=xbmcgui.INPUT_ALPHANUM, autoclose=10000)
		if keyword:
			keyword = quote(keyword)
			with open(searchHackFile, 'w') as record:
				record.write(keyword)
	if keyword: return listBroadcasts(keyword, category, page, limit)
	return None

def listLivestreams():
	debug_MS("(navigator.listLivestreams) ------------------------------------------------ START = listLivestreams -----------------------------------------------")
	FOUND = 0
	content = getUrl('https://tv.dfb.de/static/livestreams/')
	INDEX_BLANK = re.search(r'Derzeit keine Livestreams vorhanden', content)
	if not INDEX_BLANK:
		match = re.findall(r'<div class="video-teaser.*?<img src=".*?/images/(.+?)_.*?subline">(.+?)</.*?-headline">(.+?)</', content, re.S)
		for episID, subTITLE, nomTITLE in match:
			startCOMPLETE, startDATE, startTIME = (None for _ in range(3))
			FOUND += 1
			episID = episID.strip()
			subTITLE, nomTITLE = cleaning(subTITLE), cleaning(nomTITLE)
			photo = f"https://tv.dfb.de/images/{episID}_1360x760.jpg"
			relevance = subTITLE[:subTITLE.find('//')].strip()
			debug_MS(f"(navigator.listLivestreams[1]) ### TITLE : {str(relevance)} • {nomTITLE} ###")
			debug_MS(f"(navigator.listLivestreams[1]) ### IDD : {episID} || FOTO : {photo} ###")
			if str(relevance)[7:10].isdigit():
				available = datetime(*(time.strptime(relevance, '%d{0}%m{0}%Y {1} %H{2}%M'.format('.', '-', ':'))[0:6]))
				startCOMPLETE = available.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
				startDATE = available.strftime('%d{0}%m{0}%Y').format('.')
				startTIME = available.strftime('%H{0}%M').format(':')
			name = f"{startDATE} - {nomTITLE}" if startDATE else nomTITLE
			if 'jetzt live' in nomTITLE.lower() and startTIME:
				name = translation(30642).format(startTIME, nomTITLE)
			elif not 'jetzt live' in nomTITLE.lower() and startCOMPLETE:
				name = f"{startCOMPLETE} - {nomTITLE}"
			addLink(name, photo, {'mode': 'playVideo', 'url': episID, 'extras': 'LIVE'}, plot=nomTITLE+'[CR]'+subTITLE)
	if FOUND == 0: 
		return dialog.notification(translation(30524).format('VIDEOS'), translation(30525), icon, 8000)
	xbmcplugin.endOfDirectory(ADDON_HANDLE, cacheToDisc=False)

def playVideo(PID, FILTER):
	debug_MS("(navigator.playVideo) ------------------------------------------------ START = playVideo -----------------------------------------------")
	FINAL_URL, TEST_URL = (False for _ in range(2))
	FINAL_URL = getVideo(PID, FILTER)
	try: # Test ob das Video abspielbar ist !!!
		code = urlopen(FINAL_URL, timeout=6).getcode()
		if code in [200, 201, 202]: TEST_URL = True
	except: pass
	if FINAL_URL and TEST_URL:
		log(f"(navigator.playVideo) FILTER : {FILTER} || StreamURL : {FINAL_URL}")
		LSM = xbmcgui.ListItem(path=FINAL_URL)
		if enableINPUTSTREAM and ADDON_operate('inputstream.adaptive') and 'm3u8' in FINAL_URL:
			LSM.setMimeType('application/vnd.apple.mpegurl')
			LSM.setProperty('inputstream', 'inputstream.adaptive')
			LSM.setProperty('inputstream.adaptive.manifest_type', 'hls')
		xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, LSM)
	elif FINAL_URL and not TEST_URL:
		failing(f"(navigator.playVideo[1]) ##### Abspielen des Streams NICHT möglich #####\n ##### IDD : {PID} || FINAL_URL : {str(FINAL_URL)} #####\n ########## Der generierte Stream von *dfb.de* ist DEFEKT !!! ##########")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30527), icon, 10000)
	else:
		failing(f"(navigator.playVideo[2]) ##### Abspielen des Streams NICHT möglich ##### IDD : {PID} #####\n ########## KEINEN Stream-Eintrag auf der Webseite von *dfb.de* gefunden !!! ##########")
		return dialog.notification(translation(30521).format('VIDEO'), translation(30528), icon, 8000)

def getVideo(PID, FILTER):
	VIDEO, TOKEN = (None for _ in range(2))
	'''
	URL_1 = https://tv.dfb.de/server/videoConfig.php?videoid=34069&partnerid=2180&language=de&format=iphone&device=desktop
	URL_2 = https://streamaccess.unas.tv/hdflash2/vod/2180/32005.xml?streamid=32005&partnerid=2180&label=web_dfbtv&area=testarea&ident=2544593020220524221410&timestamp=20220524201410&format=iphone&auth=ed13327947b9567c8875146612a1afa7
	URL_3:
		auth="exp=1653423600~acl=*~hmac=7d04c9ae74e2e2f644f6e28c6c41880b2ab024ef3a4b7192e280cd3940dce3f0&p=2180&u=&t=hdvideo&l=web_dfbtv&a=testarea&c=DE&e=32005&i=2544593020220524221410&k=&q="
		url="https://dsdfbvod.akamaized.net/i/hdflash/2022/2022-05-25_DFB-Pokal_Best-of-2022_,300,500,800,1200,.mp4.csmil/master.m3u8"
	'''
	URL_1 = ACCESS_LINK.format(PID)
	debug_MS(f"(navigator.getVideo) ### URL_1 : {URL_1} ### FILTER : {FILTER} ###")
	FIRST = getUrl(URL_1)
	DATA_ONE = json.loads(FIRST)
	if FILTER == 'LIVE' and DATA_ONE.get('isLivestream', '') is True:
		if DATA_ONE.get('isLive', '') is False:
			debug_MS("(navigator.getVideo[1]) ### TRY TO GET LIVE-URL = NO-<islive>-FOUND ###")
			return False
	URL_2 = 'https:'+DATA_ONE['streamAccess'] if DATA_ONE.get('streamAccess', '') else None
	debug_MS(f"(navigator.getVideo[2]) ### URL_2 : {str(URL_2)} ###")
	if URL_2:
		SECOND = getUrl(URL_2)
		DATA_TWO = json.loads(SECOND)
		URL_3 = 'https:'+DATA_TWO['data']['stream-access'][0] if DATA_TWO.get('status', '') == 'success' else None
		debug_MS(f"(navigator.getVideo[3]) ### URL_3 : {str(URL_3)} ###")
		if URL_3:
			THIRD = getUrl(URL_3)
			stream = re.compile(r'url="([^"]+?)"', re.S).findall(THIRD)
			VIDEO = stream[0].replace('&amp;', '&') if stream else None
			debug_MS(f"(navigator.getVideo[4]) ### Video-URL : {str(VIDEO)} ###")
			auth = re.compile(r'auth="([^"]+?)"', re.S).findall(THIRD)
			TOKEN = auth[0].replace('&amp;', '&') if auth else None
			debug_MS(f"(navigator.getVideo[4]) ### Token-URL : {str(TOKEN)} ###")
	if VIDEO is None: return False
	START_URL = VIDEO[:VIDEO.find('_,')+2]
	END_URL = f'?hdnea={TOKEN}' if TOKEN else ""
	if FILTER == 'LIVE' and VIDEO.endswith('.m3u8'):
		debug_MS(f"(navigator.getVideo[5]) ### LIVE_URL : {VIDEO+END_URL} ###")
		return VIDEO+END_URL
	else: debug_MS(f"(navigator.getVideo[5]) ### COMPLETE_URL : {START_URL} XXX,.mp4.csmil/master.m3u8{END_URL} ###")
	if ',1200' in VIDEO and enableINPUTSTREAM: # _,300,500,800,1200,.mp4.csmil/master.m3u8?hdnea=
		return f'{START_URL}1200,.mp4.csmil/master.m3u8{END_URL}'
	elif ',1200' in VIDEO and prefQUALITY == 720:
		return f'{START_URL}1200,.mp4.csmil/master.m3u8{END_URL}'
	elif ',800' in VIDEO and prefQUALITY == 480:
		return f'{START_URL}800,.mp4.csmil/master.m3u8{END_URL}'
	elif ',500' in VIDEO and prefQUALITY == 360:
		return f'{START_URL}500,.mp4.csmil/master.m3u8{END_URL}'
	return False

def addDir(name, image, params={}, plot=None, folder=True):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name), vinfo.setPlot(plot), vinfo.setGenres(['Fussball']), vinfo.setStudios(['DFB-TV'])
	else:
		liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': plot, 'Genre': 'Fussball', 'Studio': 'DFB-TV'})
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz, isFolder=folder)

def addLink(name, image, params={}, plot=None, duration=None):
	u = '{0}?{1}'.format(HOST_AND_PATH, urlencode(params))
	liz = xbmcgui.ListItem(name)
	if plot in ['', 'None', None]: plot = "..."
	if KODI_ov20:
		vinfo = liz.getVideoInfoTag()
		vinfo.setTitle(name)
		vinfo.setPlot(plot)
		if str(duration).isdigit(): vinfo.setDuration(int(duration))
		vinfo.setGenres(['Fussball'])
		vinfo.setStudios(['DFB-TV'])
		vinfo.setMediaType('movie')
	else:
		vinfo = {}
		vinfo['Title'] = name
		vinfo['Plot'] = plot
		if str(duration).isdigit(): vinfo['Duration'] = duration
		vinfo['Genre'] = 'Fussball'
		vinfo['Studio'] = 'DFB-TV'
		vinfo['Mediatype'] = 'movie'
		liz.setInfo(type='Video', infoLabels=vinfo)
	liz.setArt({'icon': icon, 'thumb': image, 'poster': image, 'fanart': defaultFanart})
	if image and image != icon and not artpic in image:
		liz.setArt({'fanart': image})
	liz.setProperty('IsPlayable', 'true')
	liz.setContentLookup(False)
	liz.addContextMenuItems([(translation(30654), 'Action(Queue)')])
	return xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=u, listitem=liz)
