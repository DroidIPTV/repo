# -*- coding: utf-8 -*-

import base64
import xbmc
import xbmcgui
import os

api = "ewogICAgImtleXMiOiB7CiAgICAgICAgImRldmVsb3BlciI6IHt9LCAKICAgICAgICAicGVyc29uYWwiOiB7CiAgICAgICAgICAgICJhcGlfa2V5IjogIkFJemFTeUFBVzg0QnpTLVRXVTNIazVLNVBrOVZ1N2p1N2pDVUE2cyIsIAogICAgICAgICAgICAiY2xpZW50X2lkIjogIjEwMDY3NzczNTYxOTktZGF1cG4xbWlpbHBrdTlzNHVhMWliaTU5ZDU3NnJxczMiLCAKICAgICAgICAgICAgImNsaWVudF9zZWNyZXQiOiAiVTlfYndzR2pKcVpWZFdJSTJUNnA2SnA2IgogICAgICAgIH0KICAgIH0KfQ=="
json_file = "special://home/userdata/addon_data/plugin.video.youtube/api_keys.json"
api_wr = str(base64.b64decode(api)) 
api_file  = os.path.join(xbmc.translatePath(json_file))
youutube_file = open(api_file, 'w')
#youutube_file.write(api_wr)

youutube_file.write('{\n')
youutube_file.write('    "keys": {\n')
youutube_file.write('        "developer": {}, \n')
youutube_file.write('        "personal": {\n')
youutube_file.write('            "api_key": "AIzaSyAAW84BzS-TWU3Hk5K5Pk9Vu7ju7jCUA6s", \n')
youutube_file.write('            "client_id": "1006777356199-daupn1miilpku9s4ua1ibi59d576rqs3", \n')
youutube_file.write('            "client_secret": "U9_bwsGjJqZVdWII2T6p6Jp6"\n')
youutube_file.write('        }\n')
youutube_file.write('    }\n')
youutube_file.write('}\n')

dialog = xbmcgui.Dialog()
dialog.textviewer('[B][/B]', 'Starten Sie Kodi neu, falls YouTube API nicht funktionieren sollte. ')

