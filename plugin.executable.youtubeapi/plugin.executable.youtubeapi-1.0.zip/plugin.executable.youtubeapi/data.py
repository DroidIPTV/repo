{
    "keys": {
        "developer": {}, 
        "personal": {
            "api_key": "AIzaSyAAW84BzS-TWU3Hk5K5Pk9Vu7ju7jCUA6s", 
            "client_id": "1006777356199-daupn1miilpku9s4ua1ibi59d576rqs3", 
            "client_secret": "U9_bwsGjJqZVdWII2T6p6Jp6"
        }
    }
}